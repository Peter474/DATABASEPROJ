/* =====================================================
   OnlineStoreDB - 01_CreateDatabase.sql  (MS SQL Server)
   ===================================================== */
IF DB_ID('OnlineStoreDB') IS NOT NULL
BEGIN
    ALTER DATABASE OnlineStoreDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE OnlineStoreDB;
END
GO
CREATE DATABASE OnlineStoreDB;
GO
USE OnlineStoreDB;
GO

CREATE TABLE Category (
    CategoryID   INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(60)  NOT NULL UNIQUE,
    Description  NVARCHAR(200) NULL
);

CREATE TABLE Supplier (
    SupplierID  INT IDENTITY(1,1) PRIMARY KEY,
    CompanyName NVARCHAR(80) NOT NULL,
    ContactName NVARCHAR(60) NULL,
    Email       NVARCHAR(100) NOT NULL UNIQUE,
    Phone       NVARCHAR(25) NULL,
    Country     NVARCHAR(50) NOT NULL
);

CREATE TABLE Employee (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName  NVARCHAR(40) NOT NULL,
    LastName   NVARCHAR(40) NOT NULL,
    Role       NVARCHAR(40) NOT NULL,
    HireDate   DATE NOT NULL,
    Email      NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Customer (
    CustomerID     INT IDENTITY(1,1) PRIMARY KEY,
    FirstName      NVARCHAR(40) NOT NULL,
    LastName       NVARCHAR(40) NOT NULL,
    Email          NVARCHAR(100) NOT NULL UNIQUE,
    Phone          NVARCHAR(25) NULL,
    City           NVARCHAR(50) NOT NULL,
    Country        NVARCHAR(50) NOT NULL,
    RegisteredDate DATE NOT NULL
);

CREATE TABLE Product (
    ProductID    INT IDENTITY(1,1) PRIMARY KEY,
    SKU          NVARCHAR(20) NOT NULL UNIQUE,
    ProductName  NVARCHAR(100) NOT NULL,
    CategoryID   INT NOT NULL,
    SupplierID   INT NOT NULL,
    UnitPrice    DECIMAL(10,2) NOT NULL CHECK (UnitPrice >= 0),
    StockQty     INT NOT NULL DEFAULT 0 CHECK (StockQty >= 0),
    ReorderLevel INT NOT NULL DEFAULT 10,
    IsActive     BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_Product_Category FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),
    CONSTRAINT FK_Product_Supplier FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);

CREATE TABLE Orders (
    OrderID     INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID  INT NOT NULL,
    EmployeeID  INT NOT NULL,
    OrderDate   DATE NOT NULL,
    Status      NVARCHAR(20) NOT NULL DEFAULT 'Pending'
                CHECK (Status IN ('Pending','Shipped','Delivered','Cancelled')),
    ShipCity    NVARCHAR(50) NOT NULL,
    TotalAmount DECIMAL(12,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Orders_Customer FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    CONSTRAINT FK_Orders_Employee FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

CREATE TABLE OrderItem (
    OrderID   INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity  INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10,2) NOT NULL,
    Discount  DECIMAL(4,2) NOT NULL DEFAULT 0 CHECK (Discount BETWEEN 0 AND 0.90),
    CONSTRAINT PK_OrderItem PRIMARY KEY (OrderID, ProductID),
    CONSTRAINT FK_OrderItem_Order   FOREIGN KEY (OrderID)   REFERENCES Orders(OrderID),
    CONSTRAINT FK_OrderItem_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

CREATE TABLE Payment (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID   INT NOT NULL,
    Method    NVARCHAR(20) NOT NULL CHECK (Method IN ('Credit Card','PayPal','Cash on Delivery','Bank Transfer')),
    Amount    DECIMAL(12,2) NOT NULL,
    PaidDate  DATE NOT NULL,
    Status    NVARCHAR(20) NOT NULL DEFAULT 'Paid' CHECK (Status IN ('Paid','Refunded','Pending')),
    CONSTRAINT FK_Payment_Order FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

CREATE TABLE StockMovement (
    MovementID   INT IDENTITY(1,1) PRIMARY KEY,
    ProductID    INT NOT NULL,
    MovementType NVARCHAR(20) NOT NULL CHECK (MovementType IN ('Purchase','Sale','Return','Adjustment')),
    QtyChange    INT NOT NULL,
    MovementDate DATE NOT NULL,
    Note         NVARCHAR(150) NULL,
    CONSTRAINT FK_StockMovement_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

CREATE INDEX IX_Product_Category ON Product(CategoryID);
CREATE INDEX IX_Orders_Customer  ON Orders(CustomerID);
CREATE INDEX IX_Orders_Date      ON Orders(OrderDate);
GO
