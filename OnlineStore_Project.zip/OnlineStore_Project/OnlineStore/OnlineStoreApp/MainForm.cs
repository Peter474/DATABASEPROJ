using System.Data;
using Microsoft.Data.SqlClient;

namespace OnlineStoreApp;

public class MainForm : Form
{
    // ---------- shared ----------
    readonly TabControl tabs = new() { Dock = DockStyle.Fill };

    // ---------- Products tab ----------
    readonly DataGridView gridProducts = Grid();
    readonly TextBox txtSearch = new() { Width = 200 };
    readonly NumericUpDown numRestock = new() { Minimum = 1, Maximum = 10000, Value = 20, Width = 70 };
    readonly NumericUpDown numPrice = new() { Minimum = 0, Maximum = 1000000, DecimalPlaces = 2, Width = 90 };

    // ---------- New order tab ----------
    readonly ComboBox cbCustomer = Combo(), cbEmployee = Combo(), cbProduct = Combo(), cbMethod = Combo();
    readonly NumericUpDown numQty = new() { Minimum = 1, Maximum = 100, Value = 1, Width = 60 };
    readonly ComboBox cbDiscount = Combo();
    readonly DataGridView gridCart = Grid();
    readonly DataTable cart = new();
    readonly Label lblTotal = new() { AutoSize = true, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

    // ---------- Orders tab ----------
    readonly DataGridView gridOrders = Grid(), gridItems = Grid();

    // ---------- Reports tab ----------
    readonly ComboBox cbReport = Combo();
    readonly DataGridView gridReport = Grid();

    static DataGridView Grid() => new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells, BackgroundColor = Color.White
    };
    static ComboBox Combo() => new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 230 };

    public MainForm()
    {
        Text = "Online Store Management System";
        Width = 1150; Height = 720; StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);
        Controls.Add(tabs);
        BuildProductsTab(); BuildOrderTab(); BuildOrdersTab(); BuildReportsTab();
        Load += (_, _) => SafeRun(() => { LoadProducts(); LoadLookups(); LoadOrders(); });
    }

    static void SafeRun(Action a)
    {
        try { a(); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    static FlowLayoutPanel Bar() => new() { Dock = DockStyle.Top, Height = 44, Padding = new Padding(6), WrapContents = false };
    static Button Btn(string text, EventHandler click) { var b = new Button { Text = text, AutoSize = true }; b.Click += click; return b; }
    static Label Lbl(string t) => new() { Text = t, AutoSize = true, Margin = new Padding(8, 7, 2, 0) };

    // =====================================================================
    // TAB 1: PRODUCTS  (SELECT with 3-table JOIN, UPDATE price, RESTOCK = UPDATE Product + INSERT StockMovement)
    // =====================================================================
    void BuildProductsTab()
    {
        var page = new TabPage("Products");
        var bar = Bar();
        bar.Controls.AddRange(new Control[] {
            Lbl("Search:"), txtSearch, Btn("Search", (_, _) => SafeRun(LoadProducts)),
            Lbl("Restock qty:"), numRestock, Btn("Restock selected", (_, _) => SafeRun(RestockSelected)),
            Lbl("New price:"), numPrice, Btn("Update price", (_, _) => SafeRun(UpdatePrice))
        });
        page.Controls.Add(gridProducts); page.Controls.Add(bar);
        tabs.TabPages.Add(page);
    }

    void LoadProducts()
    {
        gridProducts.DataSource = Db.Table(@"
            SELECT p.ProductID, p.SKU, p.ProductName, c.CategoryName AS Category, s.CompanyName AS Supplier,
                   p.UnitPrice, p.StockQty, p.ReorderLevel
            FROM Product p
            JOIN Category c ON c.CategoryID = p.CategoryID
            JOIN Supplier s ON s.SupplierID = p.SupplierID
            WHERE p.ProductName LIKE @s OR p.SKU LIKE @s OR c.CategoryName LIKE @s
            ORDER BY p.ProductID", Db.P("@s", "%" + txtSearch.Text.Trim() + "%"));
    }

    int SelectedId(DataGridView g, string col)
    {
        if (g.CurrentRow == null) throw new Exception("Please select a row first.");
        return Convert.ToInt32(g.CurrentRow.Cells[col].Value);
    }

    // UPDATE affecting multiple tables: Product.StockQty + new StockMovement row (one transaction)
    void RestockSelected()
    {
        int pid = SelectedId(gridProducts, "ProductID");
        int qty = (int)numRestock.Value;
        using var con = Db.Open();
        using var tx = con.BeginTransaction();
        try
        {
            Db.Cmd(con, tx, "UPDATE Product SET StockQty = StockQty + @q WHERE ProductID = @p",
                Db.P("@q", qty), Db.P("@p", pid)).ExecuteNonQuery();
            Db.Cmd(con, tx, @"INSERT INTO StockMovement(ProductID, MovementType, QtyChange, MovementDate, Note)
                              VALUES(@p, 'Purchase', @q, CAST(GETDATE() AS DATE), 'Restocked from application')",
                Db.P("@p", pid), Db.P("@q", qty)).ExecuteNonQuery();
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
        LoadProducts();
        MessageBox.Show("Stock updated (Product + StockMovement).");
    }

    void UpdatePrice()
    {
        int pid = SelectedId(gridProducts, "ProductID");
        using var con = Db.Open();
        Db.Cmd(con, null, "UPDATE Product SET UnitPrice = @u WHERE ProductID = @p",
            Db.P("@u", numPrice.Value), Db.P("@p", pid)).ExecuteNonQuery();
        LoadProducts();
    }

    // =====================================================================
    // TAB 2: NEW ORDER  (INSERT affecting 5 tables in one transaction)
    // =====================================================================
    void BuildOrderTab()
    {
        cart.Columns.Add("ProductID", typeof(int)); cart.Columns.Add("Product", typeof(string));
        cart.Columns.Add("Qty", typeof(int)); cart.Columns.Add("UnitPrice", typeof(decimal));
        cart.Columns.Add("Discount", typeof(decimal)); cart.Columns.Add("LineTotal", typeof(decimal));
        gridCart.DataSource = cart;
        cbMethod.Items.AddRange(new object[] { "Credit Card", "PayPal", "Cash on Delivery", "Bank Transfer" }); cbMethod.SelectedIndex = 0;
        cbDiscount.Width = 70; cbDiscount.Items.AddRange(new object[] { "0", "0.05", "0.10", "0.15" }); cbDiscount.SelectedIndex = 0;

        var page = new TabPage("New Order");
        var bar1 = Bar(); bar1.Height = 80; bar1.WrapContents = true;
        bar1.Controls.AddRange(new Control[] { Lbl("Customer:"), cbCustomer, Lbl("Employee:"), cbEmployee, Lbl("Payment:"), cbMethod });
        var bar2 = Bar();
        bar2.Controls.AddRange(new Control[] {
            Lbl("Product:"), cbProduct, Lbl("Qty:"), numQty, Lbl("Discount:"), cbDiscount,
            Btn("Add to cart", (_, _) => SafeRun(AddToCart)), Btn("Remove line", (_, _) => SafeRun(RemoveLine)),
            Btn("Place order", (_, _) => SafeRun(PlaceOrder)), lblTotal });
        page.Controls.Add(gridCart); page.Controls.Add(bar2); page.Controls.Add(bar1);
        tabs.TabPages.Add(page);
    }

    void LoadLookups()
    {
        cbCustomer.DataSource = Db.Table("SELECT CustomerID, FirstName + ' ' + LastName + ' (#' + CAST(CustomerID AS NVARCHAR(10)) + ')' AS Name FROM Customer ORDER BY FirstName");
        cbCustomer.ValueMember = "CustomerID"; cbCustomer.DisplayMember = "Name";
        cbEmployee.DataSource = Db.Table("SELECT EmployeeID, FirstName + ' ' + LastName + ' - ' + Role AS Name FROM Employee ORDER BY FirstName");
        cbEmployee.ValueMember = "EmployeeID"; cbEmployee.DisplayMember = "Name";
        cbProduct.DataSource = Db.Table("SELECT ProductID, ProductName + ' ($' + CAST(UnitPrice AS NVARCHAR(20)) + ', stock ' + CAST(StockQty AS NVARCHAR(10)) + ')' AS Name, ProductName, UnitPrice FROM Product WHERE IsActive = 1 ORDER BY ProductName");
        cbProduct.ValueMember = "ProductID"; cbProduct.DisplayMember = "Name";
    }

    void AddToCart()
    {
        if (cbProduct.SelectedItem is not DataRowView row) return;
        int pid = (int)row["ProductID"];
        if (cart.Select($"ProductID = {pid}").Length > 0) throw new Exception("Product is already in the cart.");
        decimal price = (decimal)row["UnitPrice"], disc = decimal.Parse(cbDiscount.Text, System.Globalization.CultureInfo.InvariantCulture);
        int qty = (int)numQty.Value;
        cart.Rows.Add(pid, row["ProductName"], qty, price, disc, Math.Round(qty * price * (1 - disc), 2));
        UpdateTotal();
    }

    void RemoveLine() { if (gridCart.CurrentRow != null) { gridCart.Rows.RemoveAt(gridCart.CurrentRow.Index); UpdateTotal(); } }

    decimal CartTotal() => cart.Rows.Cast<DataRow>().Sum(r => (decimal)r["LineTotal"]);
    void UpdateTotal() => lblTotal.Text = $"   Total: {CartTotal():N2}";

    void PlaceOrder()
    {
        if (cart.Rows.Count == 0) throw new Exception("Cart is empty.");
        if (cbCustomer.SelectedValue == null || cbEmployee.SelectedValue == null) throw new Exception("Choose a customer and an employee.");
        using var con = Db.Open();
        using var tx = con.BeginTransaction();
        try
        {
            // 1) Orders
            int orderId = Convert.ToInt32(Db.Cmd(con, tx, @"
                INSERT INTO Orders(CustomerID, EmployeeID, OrderDate, Status, ShipCity, TotalAmount)
                SELECT @c, @e, CAST(GETDATE() AS DATE), 'Pending', City, 0 FROM Customer WHERE CustomerID = @c;
                SELECT CAST(SCOPE_IDENTITY() AS INT);",
                Db.P("@c", cbCustomer.SelectedValue), Db.P("@e", cbEmployee.SelectedValue)).ExecuteScalar());

            foreach (DataRow r in cart.Rows)
            {
                int pid = (int)r["ProductID"], qty = (int)r["Qty"];
                // 2) Product (stock check + decrement); WHERE guards against overselling
                int ok = Db.Cmd(con, tx, "UPDATE Product SET StockQty = StockQty - @q WHERE ProductID = @p AND StockQty >= @q",
                    Db.P("@q", qty), Db.P("@p", pid)).ExecuteNonQuery();
                if (ok == 0) throw new Exception($"Not enough stock for '{r["Product"]}'.");
                // 3) OrderItem
                Db.Cmd(con, tx, "INSERT INTO OrderItem(OrderID, ProductID, Quantity, UnitPrice, Discount) VALUES(@o,@p,@q,@u,@d)",
                    Db.P("@o", orderId), Db.P("@p", pid), Db.P("@q", qty), Db.P("@u", r["UnitPrice"]), Db.P("@d", r["Discount"])).ExecuteNonQuery();
                // 4) StockMovement
                Db.Cmd(con, tx, "INSERT INTO StockMovement(ProductID, MovementType, QtyChange, MovementDate, Note) VALUES(@p,'Sale',@n,CAST(GETDATE() AS DATE),@note)",
                    Db.P("@p", pid), Db.P("@n", -qty), Db.P("@note", "Order #" + orderId)).ExecuteNonQuery();
            }
            // total on Orders
            Db.Cmd(con, tx, "UPDATE Orders SET TotalAmount = (SELECT SUM(Quantity*UnitPrice*(1-Discount)) FROM OrderItem WHERE OrderID=@o) WHERE OrderID=@o",
                Db.P("@o", orderId)).ExecuteNonQuery();
            // 5) Payment
            Db.Cmd(con, tx, @"INSERT INTO Payment(OrderID, Method, Amount, PaidDate, Status)
                              SELECT @o, @m, TotalAmount, CAST(GETDATE() AS DATE), 'Pending' FROM Orders WHERE OrderID=@o",
                Db.P("@o", orderId), Db.P("@m", cbMethod.Text)).ExecuteNonQuery();
            tx.Commit();
            cart.Clear(); UpdateTotal();
            LoadProducts(); LoadLookups(); LoadOrders();
            MessageBox.Show($"Order #{orderId} placed successfully.");
        }
        catch { tx.Rollback(); throw; }
    }

    // =====================================================================
    // TAB 3: ORDERS  (JOIN query, UPDATE = cancel order, DELETE = delete order, all multi-table)
    // =====================================================================
    void BuildOrdersTab()
    {
        var page = new TabPage("Orders");
        var bar = Bar();
        bar.Controls.AddRange(new Control[] {
            Btn("Refresh", (_, _) => SafeRun(LoadOrders)),
            Btn("Cancel order (update)", (_, _) => SafeRun(CancelOrder)),
            Btn("Delete order", (_, _) => SafeRun(DeleteOrder)) });
        var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 330 };
        split.Panel1.Controls.Add(gridOrders); split.Panel2.Controls.Add(gridItems);
        page.Controls.Add(split); page.Controls.Add(bar);
        gridOrders.SelectionChanged += (_, _) => SafeRun(LoadItems);
        tabs.TabPages.Add(page);
    }

    void LoadOrders()
    {
        gridOrders.DataSource = Db.Table(@"
            SELECT o.OrderID, o.OrderDate, cu.FirstName + ' ' + cu.LastName AS Customer,
                   e.FirstName + ' ' + e.LastName AS HandledBy, o.Status, pay.Method, pay.Status AS PaymentStatus, o.TotalAmount
            FROM Orders o
            JOIN Customer cu ON cu.CustomerID = o.CustomerID
            JOIN Employee e  ON e.EmployeeID = o.EmployeeID
            LEFT JOIN Payment pay ON pay.OrderID = o.OrderID
            ORDER BY o.OrderID DESC");
    }

    void LoadItems()
    {
        if (gridOrders.CurrentRow == null) return;
        gridItems.DataSource = Db.Table(@"
            SELECT p.ProductName, oi.Quantity, oi.UnitPrice, oi.Discount,
                   oi.Quantity * oi.UnitPrice * (1 - oi.Discount) AS LineTotal
            FROM OrderItem oi JOIN Product p ON p.ProductID = oi.ProductID
            WHERE oi.OrderID = @o", Db.P("@o", SelectedId(gridOrders, "OrderID")));
    }

    // Puts the stock of an order back and logs it (used by cancel + delete)
    static void ReturnStock(SqlConnection con, SqlTransaction tx, int orderId, string note)
    {
        Db.Cmd(con, tx, @"UPDATE p SET p.StockQty = p.StockQty + oi.Quantity
                          FROM Product p JOIN OrderItem oi ON oi.ProductID = p.ProductID WHERE oi.OrderID = @o",
            Db.P("@o", orderId)).ExecuteNonQuery();
        Db.Cmd(con, tx, @"INSERT INTO StockMovement(ProductID, MovementType, QtyChange, MovementDate, Note)
                          SELECT ProductID, 'Return', Quantity, CAST(GETDATE() AS DATE), @n FROM OrderItem WHERE OrderID = @o",
            Db.P("@o", orderId), Db.P("@n", note)).ExecuteNonQuery();
    }

    static string StatusOf(SqlConnection con, SqlTransaction tx, int orderId) =>
        Convert.ToString(Db.Cmd(con, tx, "SELECT Status FROM Orders WHERE OrderID=@o", Db.P("@o", orderId)).ExecuteScalar());

    // UPDATE affecting Orders + Payment + Product + StockMovement
    void CancelOrder()
    {
        int id = SelectedId(gridOrders, "OrderID");
        using var con = Db.Open();
        using var tx = con.BeginTransaction();
        try
        {
            if (StatusOf(con, tx, id) == "Cancelled") throw new Exception("Order is already cancelled.");
            if (StatusOf(con, tx, id) == "Delivered") throw new Exception("Delivered orders cannot be cancelled.");
            Db.Cmd(con, tx, "UPDATE Orders SET Status='Cancelled' WHERE OrderID=@o", Db.P("@o", id)).ExecuteNonQuery();
            Db.Cmd(con, tx, "UPDATE Payment SET Status='Refunded' WHERE OrderID=@o", Db.P("@o", id)).ExecuteNonQuery();
            ReturnStock(con, tx, id, "Order #" + id + " cancelled");
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
        LoadOrders(); LoadProducts(); LoadLookups();
    }

    // DELETE affecting Payment + OrderItem + Orders (+ Product/StockMovement when stock is returned)
    void DeleteOrder()
    {
        int id = SelectedId(gridOrders, "OrderID");
        if (MessageBox.Show($"Delete order #{id} and all its items and payments?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        using var con = Db.Open();
        using var tx = con.BeginTransaction();
        try
        {
            if (StatusOf(con, tx, id) != "Cancelled") ReturnStock(con, tx, id, "Order #" + id + " deleted");
            Db.Cmd(con, tx, "DELETE FROM Payment   WHERE OrderID=@o", Db.P("@o", id)).ExecuteNonQuery();
            Db.Cmd(con, tx, "DELETE FROM OrderItem WHERE OrderID=@o", Db.P("@o", id)).ExecuteNonQuery();
            Db.Cmd(con, tx, "DELETE FROM Orders    WHERE OrderID=@o", Db.P("@o", id)).ExecuteNonQuery();
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
        LoadOrders(); LoadProducts(); LoadLookups();
    }

    // =====================================================================
    // TAB 4: REPORTS (the project's SELECT queries)
    // =====================================================================
    static readonly (string Name, string Sql)[] Reports =
    {
        ("Q2  Low-stock products", "SELECT ProductID, SKU, ProductName, StockQty, ReorderLevel FROM Product WHERE StockQty <= ReorderLevel AND IsActive = 1 ORDER BY StockQty"),
        ("Q3  Revenue per category", "SELECT c.CategoryName, SUM(oi.Quantity*oi.UnitPrice*(1-oi.Discount)) AS Revenue FROM OrderItem oi JOIN Orders o ON o.OrderID=oi.OrderID JOIN Product p ON p.ProductID=oi.ProductID JOIN Category c ON c.CategoryID=p.CategoryID WHERE o.Status<>'Cancelled' GROUP BY c.CategoryName ORDER BY Revenue DESC"),
        ("Q4  Top 5 customers", "SELECT TOP 5 cu.CustomerID, cu.FirstName+' '+cu.LastName AS Customer, cu.Country, COUNT(o.OrderID) AS Orders, SUM(o.TotalAmount) AS TotalSpent FROM Customer cu JOIN Orders o ON o.CustomerID=cu.CustomerID WHERE o.Status<>'Cancelled' GROUP BY cu.CustomerID, cu.FirstName, cu.LastName, cu.Country ORDER BY TotalSpent DESC"),
        ("Q6  Monthly revenue", "SELECT YEAR(OrderDate) AS Yr, MONTH(OrderDate) AS Mo, COUNT(*) AS Orders, SUM(TotalAmount) AS Revenue FROM Orders WHERE Status<>'Cancelled' GROUP BY YEAR(OrderDate), MONTH(OrderDate) ORDER BY Yr, Mo"),
        ("Q7  Products never ordered", "SELECT p.ProductID, p.ProductName, p.UnitPrice FROM Product p LEFT JOIN OrderItem oi ON oi.ProductID=p.ProductID WHERE oi.ProductID IS NULL"),
        ("Q8  Payments by method", "SELECT Method, Status, COUNT(*) AS Payments, SUM(Amount) AS TotalAmount FROM Payment GROUP BY Method, Status ORDER BY Method, Status"),
        ("Q9  Supplier stock value", "SELECT s.SupplierID, s.CompanyName, s.Country, COUNT(p.ProductID) AS Products, SUM(p.StockQty*p.UnitPrice) AS StockValue FROM Supplier s JOIN Product p ON p.SupplierID=s.SupplierID GROUP BY s.SupplierID, s.CompanyName, s.Country HAVING COUNT(p.ProductID)>1 ORDER BY StockValue DESC"),
        ("Q10 Best-selling products", "SELECT TOP 10 p.ProductName, SUM(oi.Quantity) AS UnitsSold FROM OrderItem oi JOIN Product p ON p.ProductID=oi.ProductID JOIN Orders o ON o.OrderID=oi.OrderID WHERE o.Status<>'Cancelled' GROUP BY p.ProductName ORDER BY UnitsSold DESC"),
        ("Q11 Orders above average", "SELECT OrderID, CustomerID, OrderDate, TotalAmount FROM Orders WHERE TotalAmount > (SELECT AVG(TotalAmount) FROM Orders) ORDER BY TotalAmount DESC"),
    };

    void BuildReportsTab()
    {
        foreach (var r in Reports) cbReport.Items.Add(r.Name);
        cbReport.Width = 300; cbReport.SelectedIndex = 0;
        var page = new TabPage("Reports");
        var bar = Bar();
        bar.Controls.AddRange(new Control[] { Lbl("Report:"), cbReport, Btn("Run", (_, _) => SafeRun(() => gridReport.DataSource = Db.Table(Reports[cbReport.SelectedIndex].Sql))) });
        page.Controls.Add(gridReport); page.Controls.Add(bar);
        tabs.TabPages.Add(page);
    }
}
