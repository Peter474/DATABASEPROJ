using System.Data;
using Microsoft.Data.SqlClient;

namespace OnlineStoreApp;

/// <summary>ADO.NET helper: connection string + small query helpers.</summary>
public static class Db
{
    // Change the server name to match your SQL Server instance (e.g. "." , "localhost\\SQLEXPRESS", "(localdb)\\MSSQLLocalDB").
    public const string ConnectionString =
        "Server=Peter\\SQLEXPRESS;Database=OnlineStoreDB;Integrated Security=True;TrustServerCertificate=True;";

    public static SqlConnection Open()
    {
        var con = new SqlConnection(ConnectionString);
        con.Open();
        return con;
    }

    /// <summary>Runs a SELECT through SqlDataAdapter and returns a DataTable.</summary>
    public static DataTable Table(string sql, params SqlParameter[] ps)
    {
        using var con = Open();
        using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddRange(ps);
        using var da = new SqlDataAdapter(cmd);
        var dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public static SqlCommand Cmd(SqlConnection con, SqlTransaction tx, string sql, params SqlParameter[] ps)
    {
        var cmd = new SqlCommand(sql, con, tx);
        cmd.Parameters.AddRange(ps);
        return cmd;
    }

    public static SqlParameter P(string name, object value) => new SqlParameter(name, value ?? DBNull.Value);
}
