/* OnlineStoreDB - 03_Queries.sql  (SELECT queries for customer/business needs) */
USE OnlineStoreDB;
GO

-- Q1. Product catalogue with category and supplier (3-table join)
SELECT p.ProductID, p.SKU, p.ProductName, c.CategoryName, s.CompanyName AS Supplier, p.UnitPrice, p.StockQty
FROM Product p
JOIN Category c ON c.CategoryID = p.CategoryID
JOIN Supplier s ON s.SupplierID = p.SupplierID
ORDER BY c.CategoryName, p.ProductName;

-- Q2. Products at or below their reorder level (inventory alert)
SELECT ProductID, SKU, ProductName, StockQty, ReorderLevel
FROM Product
WHERE StockQty <= ReorderLevel AND IsActive = 1
ORDER BY StockQty;

-- Q3. Revenue per category (excluding cancelled orders)
SELECT c.CategoryName, SUM(oi.Quantity * oi.UnitPrice * (1 - oi.Discount)) AS Revenue
FROM OrderItem oi
JOIN Orders o   ON o.OrderID = oi.OrderID
JOIN Product p  ON p.ProductID = oi.ProductID
JOIN Category c ON c.CategoryID = p.CategoryID
WHERE o.Status <> 'Cancelled'
GROUP BY c.CategoryName
ORDER BY Revenue DESC;

-- Q4. Top 5 customers by total spending
SELECT TOP 5 cu.CustomerID, cu.FirstName + ' ' + cu.LastName AS Customer, cu.Country,
       COUNT(o.OrderID) AS Orders, SUM(o.TotalAmount) AS TotalSpent
FROM Customer cu
JOIN Orders o ON o.CustomerID = cu.CustomerID
WHERE o.Status <> 'Cancelled'
GROUP BY cu.CustomerID, cu.FirstName, cu.LastName, cu.Country
ORDER BY TotalSpent DESC;

-- Q5. Order overview: customer, handling employee, number of items
SELECT o.OrderID, o.OrderDate, cu.FirstName + ' ' + cu.LastName AS Customer,
       e.FirstName + ' ' + e.LastName AS HandledBy, o.Status, COUNT(oi.ProductID) AS Lines, o.TotalAmount
FROM Orders o
JOIN Customer cu ON cu.CustomerID = o.CustomerID
JOIN Employee e  ON e.EmployeeID = o.EmployeeID
JOIN OrderItem oi ON oi.OrderID = o.OrderID
GROUP BY o.OrderID, o.OrderDate, cu.FirstName, cu.LastName, e.FirstName, e.LastName, o.Status, o.TotalAmount
ORDER BY o.OrderDate DESC;

-- Q6. Monthly revenue
SELECT YEAR(OrderDate) AS Yr, MONTH(OrderDate) AS Mo, COUNT(*) AS Orders, SUM(TotalAmount) AS Revenue
FROM Orders
WHERE Status <> 'Cancelled'
GROUP BY YEAR(OrderDate), MONTH(OrderDate)
ORDER BY Yr, Mo;

-- Q7. Products that were never ordered (LEFT JOIN)
SELECT p.ProductID, p.ProductName, p.UnitPrice
FROM Product p
LEFT JOIN OrderItem oi ON oi.ProductID = p.ProductID
WHERE oi.ProductID IS NULL;

-- Q8. Payments summary by method
SELECT Method, Status, COUNT(*) AS Payments, SUM(Amount) AS TotalAmount
FROM Payment
GROUP BY Method, Status
ORDER BY Method, Status;

-- Q9. Suppliers with more than 1 product and their stock value (GROUP BY / HAVING)
SELECT s.SupplierID, s.CompanyName, s.Country, COUNT(p.ProductID) AS Products, SUM(p.StockQty * p.UnitPrice) AS StockValue
FROM Supplier s
JOIN Product p ON p.SupplierID = s.SupplierID
GROUP BY s.SupplierID, s.CompanyName, s.Country
HAVING COUNT(p.ProductID) > 1
ORDER BY StockValue DESC;

-- Q10. Top 10 best-selling products by units sold
SELECT TOP 10 p.ProductName, SUM(oi.Quantity) AS UnitsSold
FROM OrderItem oi
JOIN Product p ON p.ProductID = oi.ProductID
JOIN Orders o  ON o.OrderID = oi.OrderID
WHERE o.Status <> 'Cancelled'
GROUP BY p.ProductName
ORDER BY UnitsSold DESC;

-- Q11. Orders whose total is above the average order total (subquery)
SELECT OrderID, CustomerID, OrderDate, TotalAmount
FROM Orders
WHERE TotalAmount > (SELECT AVG(TotalAmount) FROM Orders)
ORDER BY TotalAmount DESC;

-- Q12. Full stock history of one product (join Product + StockMovement)
SELECT p.ProductName, m.MovementDate, m.MovementType, m.QtyChange, m.Note
FROM StockMovement m
JOIN Product p ON p.ProductID = m.ProductID
WHERE p.ProductID = 1
ORDER BY m.MovementDate;
GO
